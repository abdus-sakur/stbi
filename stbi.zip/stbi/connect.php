<?php
$host='localhost';
$user='id11470167_sadstk';
$pass='sadstk458';
$database='id11470167_sadstk';

$conn=mysqli_connect($host,$user,$pass);
@mysqli_select_db($database);

?>