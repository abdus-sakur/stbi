<html>
<title>Form Upload</title>
<?php include 'navbar.php';?>
<br><br><br><br>
<br><br>
<body>
<form enctype="multipart/form-data" method="POST" action="querytf2.php">
Kata Kunci : <br>
  <input type="text" name="keyword"><br>
<input type=submit value=Submit>
</form>